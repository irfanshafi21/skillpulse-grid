# SkillPulse Grid Dataset (SIH26134)

A synthetic labour-market-to-curriculum intelligence dataset covering job demand signals, skill taxonomy, employer validation, and curriculum mapping for the IT-ITeS sector across 12 districts of Maharashtra, India.

Built to support **SkillPulse Grid**, a solution for SIH Problem Statement **SIH26134** — closing the gap between real-time job market skill demand and vocational curriculum content (ITI/CTS/PMKVY courses).

---

## ⚠️ Important: Synthetic / Demo Data

This dataset is **synthetically generated for prototype demonstration**, not scraped from live job portals. Job postings, employer votes, and demand signals are realistic in structure and distribution but are **not real company data**. Do not use this to make claims about actual Maharashtra job market conditions. See [Motivation](#motivation--problem-context) for the real-world statistics that *inspired* the design.

---

## Dataset Summary

| Property | Value |
|---|---|
| Format | SQLite (`.db`) + CSV (per table) |
| Domain | Labour market intelligence / vocational education |
| Region | Maharashtra, India (12 districts) |
| Sector coverage | IT-ITeS (1 sector, schema supports multi-sector) |
| Time span | 18 months of job posting data |
| Tables | 20 relational tables |
| Total records | ~1,000+ rows across all tables |
| License | See [License](#license) |

---

## Files

```
dataset/
├── README.md                          <- this file
├── skillpulse-grid.db                 <- full SQLite database
└── csv/                                <- one CSV per table, for non-SQL tools
    ├── District.csv
    ├── Sector.csv
    ├── TaxonomyVersion.csv
    ├── Skill.csv
    ├── Occupation.csv
    ├── OccupationSkill.csv
    ├── Employer.csv
    ├── JobPosting.csv
    ├── DemandSignal.csv
    ├── _DemandSignalPostings.csv
    ├── ValidationRequest.csv
    ├── ValidationResponse.csv
    ├── ValidationSignal.csv
    ├── Course.csv
    ├── Module.csv
    ├── CourseSkill.csv
    ├── Recommendation.csv
    ├── Candidate.csv
    ├── CandidateAssessment.csv
    ├── DistrictSector.csv
    └── AuditLog.csv
```

---

## Table Reference

### Geography & sector

**`District`** (12 rows) — Maharashtra districts with LGD (Local Government Directory) codes.
`id, lgdCode, name, stateName, createdAt`

**`Sector`** (1 row) — Industry sector definitions (IT-ITeS seeded).
`id, code, name, createdAt`

**`DistrictSector`** (12 rows) — Sector coverage/penetration score per district (0–1 scale).
`id, districtId, sectorId, coverage, createdAt`

### Skill taxonomy

**`TaxonomyVersion`** (2 rows) — Versioned taxonomy releases (ESCO-anchored), supports taxonomy evolution over time.
`id, version, baseSystem, releaseDate, notes, isCurrent, createdAt`

**`Skill`** (26 rows) — Core skill vocabulary. `altLabels` is pipe-separated synonyms (e.g. "ReactJS\|React.js"). `isEmerging`/`isDeclining` flags trend direction; `halfLifeYears` estimates skill relevance decay.
`id, uri, preferredLabel, altLabels, description, isEmerging, isDeclining, halfLifeYears, createdAt, taxonomyId, sectorId`

**`Occupation`** (5 rows) — Job roles (ESCO-style URIs), e.g. Full-Stack Developer.
`id, uri, code, preferredLabel, description, createdAt, taxonomyId, sectorId`

**`OccupationSkill`** (39 rows) — Which skills map to which occupation, with required proficiency and essential/nice-to-have flag.
`id, occupationId, skillId, proficiency, essential, createdAt`

### Demand signal pipeline

**`Employer`** (8 rows) — Employers participating in the validation quorum, with a trust `weight` and `verified` flag.
`id, name, orgId, sectorId, weight, verified, createdAt`

**`JobPosting`** (90 rows) — Synthetic job postings over an 18-month window. `rawSkillHits` stores raw keyword matches before normalization; `isDuplicate`/`isNoisy` flag data-quality issues (deliberately included to simulate real-world noisy scraped data).
`id, externalId, title, description, employerName, employerOrgId, districtId, sectorId, postedAt, isDuplicate, isNoisy, confidence, rawSkillHits, createdAt`

**`DemandSignal`** (74 rows) — Aggregated trend per skill×occupation×sector×district: posting counts, trend slope/label (emerging/stable/declining), and a computed `promotionScore` (how strongly this signal should influence curriculum).
`id, skillId, occupationId, sectorId, districtId, postingCount, sourceCount, trendSlope, trendLabel, confidence, validationState, promotionScore, periodStart, periodEnd, createdAt`

**`_DemandSignalPostings`** (441 rows) — Many-to-many join table linking each demand signal back to the individual job postings that produced it (the core traceability/evidence mechanism).
`A (DemandSignal id), B (JobPosting id)`

### Employer validation (quorum)

**`ValidationRequest`** (4 rows) — A request sent to employers to confirm/deny a candidate demand signal, with quorum thresholds (`minOrganizations`, `positiveRatioThreshold`).
`id, demandSignalId, skillId, message, threshold, minOrganizations, positiveRatioThreshold, deadline, status, createdAt`

**`ValidationResponse`** (16 rows) — Individual employer responses to a validation request.
`id, requestId, employerId, responseType, reasonCode, comment, respondedAt`

**`ValidationSignal`** (16 rows) — Finer-grained validation signal tied to a specific posting.
`id, skillId, postingId, demandSignalId, employerId, responseType, weight, reasonCode, createdAt`

### Curriculum mapping

**`Course`** (6 rows) — CTS/ITI course records.
`id, code, name, duration, occupationId, sectorId, institution, districtId, createdAt`

**`Module`** (22 rows) — Syllabus modules within a course.
`id, courseId, title, sequence, durationHours, learningOutcome, createdAt`

**`CourseSkill`** (34 rows) — Which skills a given course module actually teaches, and at what depth (`taughtProficiency`, `emphasisHours`).
`id, courseId, moduleId, skillId, taughtProficiency, emphasisHours, createdAt`

**`Recommendation`** (10 rows) — The output of the Curriculum Mirror diff engine: a suggested action (add/remove/emphasize a skill) for a course, with rationale and links back to evidence (`evidenceIds`).
`id, courseId, demandSignalId, skillId, bucket, actionType, priorityBand, suggestedOwner, rationale, evidenceIds, status, rejectionReason, createdAt, updatedAt`

### Candidates & audit

**`Candidate`** (1 row) — Sample trainee record.
`id, name, occupationId, districtId, createdAt`

**`CandidateAssessment`** (10 rows) — Skill proficiency assessments for a candidate.
`id, candidateId, skillId, proficiency, assessedAt`

**`AuditLog`** (3 rows) — System action log for traceability/governance.
`id, actor, action, entityType, entityId, payload, createdAt`

---

## Entity Relationship Summary

```
District ──< DistrictSector >── Sector ──< Skill / Occupation / Course
Skill ──< OccupationSkill >── Occupation
Skill ──< CourseSkill >── Course ──< Module
JobPosting ──< _DemandSignalPostings >── DemandSignal ──< ValidationRequest ──< ValidationResponse
DemandSignal ──< Recommendation >── Course
Employer ──< ValidationResponse / ValidationSignal
```

---

## Motivation / Problem Context

This dataset's structure was designed around real, cited statistics on India's vocational-training-to-employment gap:

- Only ~41% of PMKVY-certified candidates found employment in a recent cohort (2025 CAG audit).
- Only ~4.1% of India's 15–59 age group has received formal vocational/technical training.
- Of 170 NSQF-aligned CTS courses, only 40 have been revised on the mandated 3-year NEP cycle.
- Average tech-skill relevance half-life is estimated at ~2.5 years — shorter than the curriculum review cycle.
- Of 25 lakh ITI seats nationally, only ~10.5 lakh are filled.

The dataset's `halfLifeYears`, `trendLabel`, and `promotionScore` fields are designed to let a model or dashboard reason about *this exact mismatch* — skills going stale faster than curricula can be updated.

---

## Intended Uses

- Prototyping/demoing a labour-market-to-curriculum recommendation pipeline
- Testing skill-taxonomy matching and normalization logic (`altLabels`)
- Building and testing a "curriculum gap" diff algorithm (compare `CourseSkill` vs `DemandSignal`)
- Simulating an employer-validation/quorum consensus mechanism
- UI/dashboard development without needing a live data pipeline

## Out-of-scope Uses

- Making factual claims about real Maharashtra employers, real job postings, or real candidates (all synthetic)
- Production deployment without replacing synthetic data with a live ingestion pipeline

---

## How to Load

**SQLite directly:**
```bash
sqlite3 skillpulse-grid.db
.tables
.schema DemandSignal
```

**Python (pandas):**
```python
import sqlite3, pandas as pd
con = sqlite3.connect("skillpulse-grid.db")
demand = pd.read_sql("SELECT * FROM DemandSignal", con)
```

**CSV (any tool):** load any file under `csv/` directly — one table per file, headers included.

**Prisma (original app):** point `DATABASE_URL` in `.env` to this file to run the full SkillPulse Grid app against it.

---

## License

Choose one before publishing (recommend **CC BY 4.0** for a hackathon dataset, since it's synthetic and freely shareable — update this section with your team's actual choice):

> This dataset is released under [LICENSE NAME]. See `LICENSE` file for details.

## Citation

If referencing this dataset in your SIH submission/report:

```
SkillPulse Grid Dataset (2026). Synthetic labour-market-to-curriculum
demand dataset for SIH26134. [Your Team Name], Smart India Hackathon 2026.
```

## Contact / Maintainers

Team: [Add team name]
Problem Statement: SIH26134 — Department of Skills, Employment, Entrepreneurship and Innovation, Government of Maharashtra
